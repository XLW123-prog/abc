package If语句;

import java.util.Scanner;

public class 是否构成三角形 {
    public static void main(String[] args) {
        //键盘录入三边
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入第一个边的长度：");
        int a = sc.nextInt();
        System.out.println("请输入第二个边的长度：");
        int b = sc.nextInt();
        System.out.println("请输入第三个边的长度：");
        int c = sc.nextInt();
        if(a+b>c&&a+c>b&&b+c>a){
            System.out.println("三边可以构成三角形");
        }else{
            System.out.println("三边不能构成三角形");
        }
        //判断是否构成三角形

            //判断三角形的类型
            if(a==b||a==c||b==c){
                System.out.println("这是一个等腰三角形");
            }else if(a==b&&b==c){
                System.out.println("这是一个等边三角形");
            }else{
                System.out.println("这是一个普通三角形");
            }

            }
            }





